package com.example.myshops.fragments

import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.myshops.R
import com.example.myshops.data.PurchaseViewModel
import com.example.myshops.data.Purchases
import com.example.myshops.databinding.FragmentAddBinding

class addFragment : Fragment() {
    lateinit var binding: FragmentAddBinding
    private  lateinit var mPurchasesViewModel: PurchaseViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        mPurchasesViewModel = ViewModelProvider(this).get(PurchaseViewModel::class.java)
        binding = FragmentAddBinding.inflate(inflater)
        binding.addbutton.setOnClickListener {
            insertDataToDatabase()
        }
        return binding.root
    }


    private fun insertDataToDatabase(){
        val name = binding.addname.text.toString()
        val desc = binding.adddesc.text.toString()

        if(inputChek(name)){
            //Создаем БД
            val purchases = Purchases(0,name,desc)
                //Добавляем данные в ДБ
            mPurchasesViewModel.addPurchases(purchases)
            Toast.makeText(requireContext(),"Успешно добавлено", Toast.LENGTH_SHORT).show()
                //Возврващаемся назад после добавления( можно будет потом убрать это, если станет неудобно)
            findNavController().navigate(R.id.action_addFragment_to_listFragment)
    }else{
        Toast.makeText(requireContext(), "Введите имя товара", Toast.LENGTH_SHORT).show()
    }
    }

    private fun inputChek(name:String): Boolean{
        return !(TextUtils.isEmpty(name))

    }




}