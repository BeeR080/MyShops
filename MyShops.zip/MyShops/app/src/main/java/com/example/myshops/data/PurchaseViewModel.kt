package com.example.myshops.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PurchaseViewModel(application: Application) : AndroidViewModel(application) {

    val readAllData: LiveData<List<Purchases>>
    private val repository: PurchaseRepository

    init{
        val purchasesDao = PurchasesDatabase.getDatabase(application).purchasesDao()
        repository = PurchaseRepository(purchasesDao)
        readAllData = repository.readAllData
    }
        //Добавить покупку
    fun addPurchases(purchase: Purchases){
        viewModelScope.launch(Dispatchers.IO){
            repository.addPurchases(purchase)

        }
    }
        // Изменить покупку
    fun updatePurchase(purchase: Purchases){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updatePurchase(purchase)
        }
    }
    // Удалить покупку
    fun deletePurchase(purchase: Purchases){
        viewModelScope.launch(Dispatchers.IO){
            repository.deletePurchase(purchase)
        }
    }
}