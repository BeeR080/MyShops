package com.example.myshops.fragments

import android.os.Bundle
import android.text.TextUtils
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myshops.ListOfPurchasesAdapter
import com.example.myshops.R
import com.example.myshops.data.PurchaseViewModel
import com.example.myshops.data.Purchases
import com.example.myshops.databinding.FragmentListBinding
import kotlinx.android.synthetic.main.fragment_update.*

class ListFragment : Fragment() {

    lateinit var binding: FragmentListBinding
    lateinit var mPurchasesViewModel: PurchaseViewModel


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentListBinding.inflate(inflater)

        // RecyclerView
        val adapter = ListOfPurchasesAdapter()
        val recyclerView = binding.recyclerview
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())


        //PurchasesViewModel
        mPurchasesViewModel = ViewModelProvider(this).get(PurchaseViewModel::class.java)
        mPurchasesViewModel.readAllData.observe(viewLifecycleOwner, Observer { purchases ->
            adapter.setData(purchases)
        })



        binding.addbutton.setOnClickListener {
            findNavController().navigate(R.id.action_listFragment_to_addFragment)
        }

        return binding.root
    }


    companion object {
        @JvmStatic
        fun newInstance() = ListFragment()
    }





}

