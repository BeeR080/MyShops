package com.example.myshops.data

import android.os.FileObserver.DELETE
import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface PurchasesDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addPurchases(purchases: Purchases)

    @Update
    suspend fun updatePurchase(purchases: Purchases)

    @Delete
    suspend fun deletePurchase(purchases: Purchases)

    @Query("SELECT * FROM my_purchases ORDER BY id ASC")
    fun readAllData(): LiveData<List<Purchases>>
}