package com.example.myshops

import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import android.widget.Toast.makeText
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.findFragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.FragmentNavigator
import androidx.navigation.fragment.FragmentNavigatorDestinationBuilder
import androidx.recyclerview.widget.RecyclerView
import com.example.myshops.data.Purchases
import com.example.myshops.fragments.ListFragment
import com.example.myshops.fragments.ListFragmentDirections

import kotlinx.android.synthetic.main.purchases_list.view.*

class ListOfPurchasesAdapter:RecyclerView.Adapter<ListOfPurchasesAdapter.MyViewHodler>() {
private var purchaseList = emptyList<Purchases>()



    class MyViewHodler(itemView: View):RecyclerView.ViewHolder(itemView) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHodler {
        return MyViewHodler(LayoutInflater.from(parent.context).inflate(R.layout.purchases_list, parent , false))

    }

    override fun onBindViewHolder(holder: MyViewHodler, position: Int) {
        val curentItem = purchaseList[position]
        holder.itemView.findViewById<TextView>(R.id.addname_rc).text = curentItem.purchaseName.toString()
        holder.itemView.findViewById<TextView>(R.id.adddesc_rc).text = curentItem.purchaseDesc.toString()

            //Нажатие на элементы списка
        holder.itemView.listLayout.setOnLongClickListener{

            val actions = ListFragmentDirections.actionListFragmentToUpdateFragment(curentItem)
            holder.itemView.findNavController().navigate(actions)
            return@setOnLongClickListener true
        }

    }
    override fun getItemCount(): Int {
       return purchaseList.size
    }
    fun setData(purchases:List<Purchases>){
        this.purchaseList = purchases
        notifyDataSetChanged()
    }




}


